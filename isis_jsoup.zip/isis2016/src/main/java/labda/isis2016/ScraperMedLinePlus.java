package labda.isis2016;

import org.jsoup.nodes.Document;



import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;


public class ScraperMedLinePlus {

	
	public static final String MEDLINEPLUS="https://medlineplus.gov/spanish/";
	public static final String MEDLINEPLUS_BROWSEDRUG="https://medlineplus.gov/spanish/druginformation.html";
	
	/**
	 * Devuelve un array con todas las urls para cada una de las letras del abecedario en medlineplus 
	 * @return
	 * @throws IOException
	 */
	public static String[] getABC() throws IOException {
		Document doc = Jsoup.connect(MEDLINEPLUS_BROWSEDRUG).get();
		Elements lst=doc.select("ul[class=alpha-links] > li");
		String[] aLinks=new String[lst.size()];
		int i=0;
		for (Element elem:lst) {
			String link=MEDLINEPLUS+elem.getElementsByTag("a").attr("href");
			//System.out.println(link);
			aLinks[i]=link;
			i++;
		}
		return aLinks;

	}
	
	/**
	 * Recibe la página web que contiene el listado de fármacos de que empiezan por una determinada letra
	 * y devuelve las url de las páginas de todos esos fármacos
	 * @param urlLetter
	 * @return
	 * @throws IOException
	 */
	public static String[] getDrugs(String urlLetter) throws IOException {
		Document doc = Jsoup.connect(urlLetter).get();
		Elements lst=doc.select("a[href*=./meds/]");
		String[] aLinks=new String[lst.size()];
		int i=0;
		for (Element elem:lst) {
			String link=elem.attr("href");
			link=MEDLINEPLUS+"druginfo"+link.substring(1);
			//System.out.println("\t"+link);
			aLinks[i]=link;
			i++;
		}
		return aLinks;
	}
	
	public static void main(String args[]) throws IOException {
		String[] linksLetters=getABC();
		
		ArrayList<String> allDrugs=new ArrayList<String>();
		for (String url:linksLetters) {
			String[] aDrugs=getDrugs(url);
			allDrugs.addAll(Arrays.asList(aDrugs));
		}
		
		for (String linkDrug:allDrugs) {
			String text=getHow(linkDrug);
		}
		
	}
	
	
	/**
	 * método que recoge la sección "Cómo se debe usar". 
	 * @param urlDrug
	 * @return
	 * @throws IOException
	 */
	public static String getHow(String urlDrug) throws IOException {
		Document doc = Jsoup.connect(urlDrug).get();
		System.out.println("Processing " + urlDrug);
		Elements lst=doc.select("div[class=section-header]:contains(¿Cómo se debe usar este medicamento?) + div > p");
		StringBuffer out=new StringBuffer();
		for (Element elem:lst) {
			out.append(elem.text()+"\n");
		}
		return out.toString();
	}
}

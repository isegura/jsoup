package labda.isis2016;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Sraper {
	
	public static final String URL_DIC_ACR="http://www.laenfermeria.es/docuwiki/doku.php?id=siglas_medicas";
	public static final String URL_WIKIE="https://es.wikipedia.org/";

	public static final String URL_EMAGLOSS="http://www.ema.europa.eu/ema/index.jsp?curl=pages/document_library/landing/glossary.jsp";
	public static final String URL_EMA="http://www.ema.europa.eu/ema/";
	
	public static final String URL_EMA_HUMANDRUS="http://www.ema.europa.eu/ema/index.jsp?curl=pages/medicines/landing/epar_search.jsp";

	public static void main(String args[]) throws IOException  {
		
		getImgs("http://www.eldiario.es");
		//getSiglas();
		//getGlossaryEMA();
	}
	
	
	
	/**
	 * Método que descarga el gglosario de la EMA. Primero descarga el vocabulario
	 * @throws IOException
	 */
		
	public static void getGlossaryEMA() throws IOException{
		Document doc = Jsoup.connect(URL_EMAGLOSS).get();
		Elements lst = doc.select("ul[class=alphabet] li");
		StringBuffer out=new StringBuffer();
		for (Element elem: lst) {
			//char letra=elem.text().trim().charAt(0);
			try {
				String link=elem.getElementsByTag("a").attr("href");
				if (link!=null && link.length()>0) 
					//System.out.println("\t"+letra+" " + link);
		    		link=URL_EMA+link;
		    		//System.out.println("\t"+letra+" " + link);
		    		String str=extractTerms(link);
		    		out.append(str);
					System.out.println();
					System.out.println();

					
			} catch (Exception e) {
				
			}
	    		
	    }
	    writeToFile(out.toString(),"GlossarioEMA.txt");

		System.out.println();
	}
	
	/**
	 * Método que extrae los términos y sus definición del glosario de EMA
	 * @param url
	 * @return
	 * @throws IOException
	 */
	private static String extractTerms(String url)  throws IOException{
		Document doc = Jsoup.connect(url).get();
		Elements lst = doc.select("dl");
		StringBuffer out=new StringBuffer();
		Element content=lst.first();
		Elements lstTerm=content.getElementsByTag("dt");
		Elements lstDef=content.getElementsByTag("dd");
		for (int i=0; i<lstTerm.size(); i++) {
			String term=lstTerm.get(i).text();
			String def=lstDef.get(i).text();
			System.out.println("\t"+term.toUpperCase()+": "+def);
			out.append(term.toUpperCase()+": " + def + "\n");
		}
		return out.toString();
		
		
	}
	/**
	 * buscar todos las siglas médicas y su definición de la página 
	 * http://www.laenfermeria.es/docuwiki/doku.php?id=siglas_medicas
	 * @param url
	 * @throws IOException
	 */
	public static void getSiglas() throws IOException{
		Document doc = Jsoup.connect(URL_DIC_ACR).get();
		//selecciona todos los elementos p que contengan una etiqueta strong
		Elements lst = doc.select("p:has(strong)"); 
		StringBuffer out=new StringBuffer();
	    for (Element elem: lst) {
	    	System.out.println("\t"+elem.text());
	    	out.append(elem.text()+"\n");
	    }
	    
	    writeToFile(out.toString(),"siglas.txt");
	}
	
	//método auxiliar para grabar un string en un fichero
	private static void writeToFile(String str,String nameFile) throws IOException {
		BufferedWriter bwr = new BufferedWriter(new FileWriter(new File(nameFile)));
	    bwr.write(str);
	    bwr.flush();
	    bwr.close();
	    System.out.println(nameFile + " saved!!!");
}

	
	/**
	 * Este método debe recuperar todos las imágenes
	 * @param url
	 * @throws IOException
	 */
	public static void getImgs(String url) throws IOException{
		Document doc = Jsoup.connect(url).get();
		System.out.println("Imgs from:\t"+doc.title());
		//Elements lst = doc.select("img[src~=.jpg"); //terminan
		Elements lst = doc.select("img[src*=logo]");  //contienen
	    for (Element elem: lst)
	    	System.out.println("\t"+elem.attr("src"));
	}
	
	
	
	/**
	 * Este método debe recuperar todos los a href y mostrar su texto asociado.
	 * @param url
	 * @throws IOException
	 */
	public static void getHref(String url) throws IOException{
		Document doc = Jsoup.connect(url).get();
		System.out.println("a href from:\t"+doc.title());
		Elements lst = doc.select("a[href]"); // a with href
	    for (Element elem: lst)
	    	System.out.println("\t"+elem.text());
	}
	
	
	
	
		
	
	/**
	 * Este método debería recuperar el título de cualquier página html
	 * @param url
	 * @throws IOException
	 */
	public static void getTitle(String url) throws IOException{
		Document doc = Jsoup.connect(url).get();
		System.out.println(url+":\t"+doc.title());
		System.out.println();
	}
	

		
	
//
//	/**
//	 * Este método debería recuperar el título de cualquier página html
//	 * @param url
//	 * @throws IOException
//	 */
//	public static void getImages(String url) throws IOException{
//		Document doc = Jsoup.connect(url).get();
////		//
////		Document doc = Jsoup.connect(url)
////		.userAgent("Mozilla")
////		  .cookie("auth", "token")
////		  .timeout(3000)
////		  .post();
//		System.out.println("Images from :\t"+doc.title());
//		
//		Elements lst=doc.select("img");
//	    for (Element elem: lst)
//	          System.out.println("\t"+elem.attr("src")+"\t"+elem.attr("alt"));
//	    
//	    System.out.println();
//	}
//	
//	


}
